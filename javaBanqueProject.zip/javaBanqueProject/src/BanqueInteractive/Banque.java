package BanqueInteractive;
import BanqueInteractive.Client;
import BanqueInteractive.Compte;
public class Banque {

    float banqueId;
    private String nomBanque;
    private Client[] clients;
    private int nbClients;

    public Banque(float banqueId, String nomBanque, int nbClients) {
        this.banqueId = banqueId;
        this.nomBanque = nomBanque;
        this.nbClients = nbClients;
    }

    public Client[] getClients() {
        return this.clients;
    }

    public Client ajouterClient(Client client) {
        for (int i = 0; i < this.clients.length; i++) {
            this.clients[i] = client;
            break;
        }
        System.out.println("le Client" + client.getNom() + "a été ajouté");
        return client;

    }

    public void bilanClient(Client client) {
        for (Compte compte : client.getComptes()) {

            System.out.println("Numero de compte: " + compte.getNumeroCompte());
            System.out.println("Solde du compte: " + compte.getSolde());

        }
    }

    public void afficherBilan() {
        for (Client client : this.clients) {

            System.out.println("Le client " + client.getNom() + " dont l'Id: " + client.getClientId());
            bilanClient(client);

        }
    }

}



