package BanqueInteractive;
import java.util.Scanner;
import BanqueInteractive.Compte;
import java.util.Scanner;
import BanqueInteractive.Banque;
import BanqueInteractive.Client;
public class BanqueInteractive {
    float clienId;
    String nomClient;
    int nbComptes;
    Banque banque;
    public BanqueInteractive(Banque banque) {
        this.banque = banque;
    }
    Scanner scanner = new Scanner();
    public int choixOperationBanque(Scanner scanner){
        System.out.println("Quelle opération voulez-vous effectuer ?");
        System.out.println("1 Ajouter un client");
        System.out.println("2 Effectuer une opération sur un client");
        System.out.println("3 Afficher un bilan général");
        System.out.print("- ");
        int operationBanque = scanner.nextInt();
        scanner.nextLine();
        return  operationBanque;}

    public String inputNomClient(Scanner scanner){
        System.out.println("Entrez le nom du client :");
        System.out.print("- ");
        String nomduClient = scanner.nextLine();
        return nomduClient;
    }

    public int choixOperationClient(){
        System.out.println("Quelle opération voulez-vous effectuer ?");
        System.out.println("1 Afficher un bilan");
        System.out.println("2 Faire un retrait");
        System.out.println("3 Faire un dépot");
        System.out.println("4 Faire un virement");
        System.out.print("- ");
        int operationClient = scanner.nextInt();
        return operationClient;
    }
    }