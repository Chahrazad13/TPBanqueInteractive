package BanqueInteractive;

import java.util.Arrays;

import static java.lang.System.*;
public class Client {
    private Compte[] comptes;
    private String nomClient;
    private int clientId;
    static int nbComptes;

    public Client(String nomClient) {
        this.nomClient = nomClient;
        this.comptes = new Compte[100];
    }

    public Compte[] getComptes(){
        return this.comptes;
    }

    public void ajouterCompte() {
        comptes[nbComptes] = new Compte(this.nbComptes);
        this.nbComptes++;
    }

    public String getNom() {
        return nomClient;
    }

    public float getSoldeClient() {
        return comptes[nbComptes].getSolde();
    }

    //
    public float afficherSoldeClient() {
        out.println(Arrays.toString(comptes));
        for (int i = 0; i < nbComptes; i++) {
            comptes[i].afficherSolde();

        }}

    public int getClientId () {
        return this.clientId;}
    }

