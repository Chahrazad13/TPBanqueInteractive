package BanqueInteractive;
public class Compte {
    float numeroCompte;
    float soldeCompte;

    public Compte(float numeroCompte) {
        this.numeroCompte = numeroCompte;
     //   this.soldeCompte = soldeCompte;
    }
    public void depot(float montantDepose){
        soldeCompte = soldeCompte + montantDepose;
        System.out.println("le montant déposé est " + montantDepose);
    }
    public void retrait(float montantRetire){
        soldeCompte = soldeCompte - montantRetire;
        System.out.println("le montant retiré est " + montantRetire);
    }
    public float getSolde(){
        return soldeCompte;
    }

    public void afficherSolde(){
        System.out.println("le solde est " + soldeCompte + " euros");
    }

   public void virer(float argentvire,Compte destinataire){

    this.depot(argentvire);

   }
    public Float getNumeroCompte() {
        return numeroCompte;
    }
}
/*
public static void main(String[] args){
    Compte compteChahrazad= new Compte(2,12000);
    Compte compteKamran= new Compte(3,12000);

        compteChahrazad.afficherSolde();
                compteKamran.afficherSolde();
                compteKamran.virer(100,compteChahrazad);
                compteChahrazad.afficherSolde();
                compteKamran.afficherSolde();}
 */


