import BanqueInteractive.Client;
import BanqueInteractive.Compte;

public class Main {
    public static void main(String[]args) {
        /* 3.1/ Un utilisateur a un compte unique:
        Compte compte= new Compte(1, 13000);
        Client client = new Client(compte,"Chahrazad", 3);
        client.getNom();
        client.getSoldeClient();
        client.afficherSoldeClient();

        */

        // 3.2/ Un utilisateur a plusieurs comptes:

        Client client = new Client("Lana");
        client.ajouterCompte();
        client.ajouterCompte();
        client.afficherSoldeClient();
    }}